﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalChallenge.Domain
{
    public class OrderManager
    {
        public static void CreateOrder(DTO.OrderDTO orderDTO)
        {
            /*  
             *  THIS WAS ALL DUMMY DATA TO MAKE SURE EVERYTHING WAS WIRED UP PROPERLY TO THE DB. 
             *  
            var order = new DTO.OrderDTO();
            order.OrderId = Guid.NewGuid();
            order.Size = DTO.Enums.SizeType.Large;
            order.Crust = DTO.Enums.CrustType.Thick;
            order.Pepperoni = true;
            order.Name = "Me";
            order.Address = "123 Here";
            order.Zip = "1111111";
            order.Phone = "5555555555";
            order.PaymentType = DTO.Enums.PaymentType.Credit;
            order.TotalCost = 16.50M;
            */

            //Validation

            if (orderDTO.Name.Trim().Length == 0)
            {
                throw new Exception("Name is required.");
            }

            if (orderDTO.Address.Trim().Length == 0)
            {
                throw new Exception("Address is required.");
            }

            if (orderDTO.Zip.Trim().Length == 0)
            {
                throw new Exception("Zip is required.");
            }

            if (orderDTO.Phone.Trim().Length == 0)
            {
                throw new Exception("Phone number is required.");
            }

            orderDTO.OrderId = Guid.NewGuid();
            orderDTO.TotalCost = PizzaPriceManager.CalculateCost(orderDTO);
            Persistence.OrderRepository.CreateOrder(orderDTO);
        }

        public static void CompleteOrder(Guid orderId)
        {
            Persistence.OrderRepository.CompleteOrder(orderId);
        }

        public static object GetOrders()
        {
            return Persistence.OrderRepository.GetOrdersData();
        }
    }
}
