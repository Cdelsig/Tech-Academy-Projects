﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;

namespace StringVsStringBuilder
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void stringButton_Click(object sender, EventArgs e)
        {
            string myString = "Hello! This is an example of a string.";
            myString += " A new string had to be created in memory to generate this line!";

            resultLabel.Text = myString;
        }

        protected void stringBuilderButton_Click(object sender, EventArgs e)
        {
            StringBuilder sb = new StringBuilder("");
            sb.Append("Hello! ");
            sb.Append("This is an example of a string, ");
            sb.Append("generated with a new instance of the StringBuilder class! ");
            sb.Append("This is the original string in memory, modified a few times.");

            resultLabel.Text = sb.ToString();

        }
    }
}