﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using AngelsPlants.Models;

namespace AngelsPlants.DAL
{
    public class AngelsInitializer : System.Data.Entity.DropCreateDatabaseIfModelChanges<AngelsContext>
    {
        protected override void Seed(AngelsContext context)
        {
            var plants = new List<Plant>
            {
                new Plant{CommonName="Sunflower", ScientificName="Helianthus annuus", ImageUrl="Sunflower.jpg"},
                new Plant{CommonName="Snapdragon", ScientificName="Antirrhinum majus", ImageUrl="Snapdragon.jpg"},
                new Plant{CommonName="Lavender", ScientificName="‎Lavandula angustifolia", ImageUrl="Lavender.jpg"},
                new Plant{CommonName="Aloe Vera", ScientificName="Aloe barbadensis", ImageUrl="AloeVera.jpg"},
                new Plant{CommonName="Prickly Pear Cactus", ScientificName="Opuntia ficus-indica", ImageUrl="PricklyPear.jpg"},
                new Plant{CommonName="Evecheria", ScientificName="Evecheria 'White Rose'", ImageUrl="Evecheria.jpg"}
            };

            plants.ForEach(s => context.Plants.Add(s));
            context.SaveChanges();

            var newsletters = new List<Newsletter>
            {
                new Newsletter{FirstName="Manny", LastName="ManMan", PhoneNumber="111-222-3333", Email="Manny@domain.com"},
                new Newsletter{FirstName="Lily", LastName="Padd", PhoneNumber="222-333-4444", Email="Lily.Padd@here.com"},
                new Newsletter{FirstName="Fern", LastName="Gully", PhoneNumber="333-444-5555", Email="iLuvPlants@there.com"}
            };

            newsletters.ForEach(s => context.Newsletters.Add(s));
            context.SaveChanges();
        }
    }
}