﻿using AngelsPlants.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.ModelConfiguration.Conventions;
using System.Linq;
using System.Web;

namespace AngelsPlants.DAL
{
    public class AngelsContext : DbContext
    {
        public AngelsContext() : base("AngelsContext")
        {
        }

        public DbSet <Plant> Plants { get; set; }
        public DbSet <Newsletter> Newsletters { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();
        }
    }
}